<template>
  <div class="processing-container">
    <div class="content">
      <div class="image-preview">
        <img :src="uploadedImage" alt="Uploaded" />
      </div>
      
      <div class="progress-section">
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: progress + '%' }"></div>
        </div>
        <div class="text-section">
          <p class="status-text-en">Uploading...</p>
          <p class="status-text-zh">上传中</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const uploadedImage = ref('https://images.unsplash.com/photo-1511895426328-dc8714191300?w=400&h=500&fit=crop')
const progress = ref(0)

onMounted(() => {
  const storedFiles = localStorage.getItem('uploadedFiles')
  if (storedFiles) {
    const files = JSON.parse(storedFiles)
    if (files && files.length > 0) {
      uploadedImage.value = files[0].preview
    }
  }

  const interval = setInterval(() => {
    if (progress.value < 60) {
      progress.value += 2
    } else {
      clearInterval(interval)
      setTimeout(() => {
        router.push('/destroying')
      }, 500)
    }
  }, 50)
})
</script>

<style scoped>
.processing-container {
  width: 100%;
  height: 100vh;
  background: #0F0E20;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 60px;
  padding: 0 30px;
}

.image-preview {
  width: 320px;
  height: 400px;
  border-radius: 24px;
  overflow: hidden;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
}

.image-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.progress-section {
  width: 100%;
  max-width: 340px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.progress-bar {
  width: 100%;
  height: 12px;
  background: rgba(26, 29, 46, 0.8);
  border-radius: 6px;
  border: 1px solid rgba(168, 85, 247, 0.3);
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #06b6d4 0%, #3b82f6 50%, #a855f7 100%);
  transition: width 0.3s ease;
  box-shadow: 0 0 10px rgba(168, 85, 247, 0.6);
}

.text-section {
  text-align: center;
}

.status-text-en {
  font-size: 18px;
  color: rgba(6, 182, 212, 0.9);
  margin: 0 0 6px 0;
  font-weight: 400;
}

.status-text-zh {
  font-size: 14px;
  color: rgba(6, 182, 212, 0.7);
  margin: 0;
}

@media (max-width: 480px) {
  .image-preview {
    width: 280px;
    height: 350px;
  }
}
</style>
